#!/sbin/sh
SKIPUNZIP=1

ui_print "= CuUtilMonitor Module ="
ui_print "- Installing..."

ui_print "- Extracting module files."
unzip -o "$ZIPFILE" -x "META-INF/*" -d "$MODPATH" >/dev/null 2>&1

ui_print "- Set permissions."
chmod -R 0777 "$MODPATH"

ui_print "- Installation finished."
